<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* -- Hear ye, hear ye --

The email settings are now taking place in
libraries/My_Email.php Most (or all) of the ones you
need to worry about are editable from the
settings page of the admin panel.

This public service announcement was sponsored in
part by www.unruhdesigns.com  :)
*/