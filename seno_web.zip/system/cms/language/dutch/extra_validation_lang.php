<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']		= "Het veld %s mag alleen alfanumerieke karakters, underscores, punten en minnen bevatten.";
$lang['decimal']			= "Het veld %s mag alleen decimale karakters bevatten.";
$lang['csrf_bad_token']		= "Ongeldig CSRF Token";

/* End of file extra_validation_lang.php */