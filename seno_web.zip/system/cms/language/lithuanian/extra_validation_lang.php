<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= " %s laukelyje galima naudoti tik lotyniškos abėcėlės simbolius, pabraukimus, taškus ir brūkšnius.";
$lang['decimal']				= "%s laukelyje galima naudoti tik dešimtainius skaičius.";
$lang['csrf_bad_token']			= "Negaliojantis CSRF Token";

/* End of file extra_validation_lang.php */