<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['streams:api.empty_stream_name'] 						= 'No stream name provided.';
$lang['streams:api.empty_stream_slug'] 						= 'No stream slug provided.';
$lang['streams:api.stream_slug_in_use'] 					= 'Stream slug in use.';
$lang['streams:api.empty_field_name'] 						= 'No field name provided.';
$lang['streams:api.empty_field_slug'] 						= 'No field slug provided.';
$lang['streams:api.field_slug_in_use'] 						= 'Field slug in use.';