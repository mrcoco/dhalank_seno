<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['streams:api.empty_stream_name'] = 'Aucun nom de stream fournit.';
$lang['streams:api.empty_stream_slug'] = 'Aucun slug de stream fournit.';
$lang['streams:api.stream_slug_in_use'] = 'Slug de Stream en cours d\'utilisation.';
$lang['streams:api.empty_field_name'] = 'Aucun nom de champ fournit.';
$lang['streams:api.empty_field_slug'] = 'Aucun champ slug fournit.';
$lang['streams:api.field_slug_in_use'] = 'Champ Slug en cours d\'utilisation.';