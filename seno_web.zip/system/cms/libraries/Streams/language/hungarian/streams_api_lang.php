<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['streams:api.empty_stream_name']                           = 'Nem adtál nevet az adatfolyamnak.';
$lang['streams:api.empty_stream_slug']                           = 'Nem adtál meg keresőbarát URL-t az adatfolyamhoz.';
$lang['streams:api.stream_slug_in_use']                          = 'Az adatfolyam keresőbarát URL-je már használatban van.';
$lang['streams:api.empty_field_name']                            = 'Nincs megadva mezőnév.';
$lang['streams:api.empty_field_slug']                            = 'Nincs megadva keresőbarát URL a mezőnévhez.';
$lang['streams:api.field_slug_in_use']                           = 'A mezőhöz tartozó keresőbarát URL már használatban van.';

/* End of file streams_api_lang.php */