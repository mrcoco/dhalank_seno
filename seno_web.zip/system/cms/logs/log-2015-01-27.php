<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-27 14:28:43 --> Page Missing: js/jquery.js
ERROR - 2015-01-27 14:28:45 --> Page Missing: css/prettyPhoto.css
ERROR - 2015-01-27 14:28:47 --> Page Missing: css/animate.css
ERROR - 2015-01-27 14:28:49 --> Page Missing: css/font-awesome.min.css
ERROR - 2015-01-27 14:28:50 --> Page Missing: css/main.css
ERROR - 2015-01-27 14:28:51 --> Page Missing: css/bootstrap.min.css
ERROR - 2015-01-27 14:28:53 --> Page Missing: js/bootstrap.min.js
ERROR - 2015-01-27 14:28:56 --> Page Missing: js/jquery.prettyPhoto.js
ERROR - 2015-01-27 14:28:57 --> Page Missing: js/main.js
ERROR - 2015-01-27 14:29:00 --> Page Missing: images/ico/favicon.ico
ERROR - 2015-01-27 14:29:01 --> Page Missing: images/logo.png
ERROR - 2015-01-27 14:29:03 --> Page Missing: images/portfolio/recent/item1.png
ERROR - 2015-01-27 14:29:05 --> Page Missing: images/portfolio/recent/item3.png
ERROR - 2015-01-27 14:29:06 --> Page Missing: images/portfolio/recent/item2.png
ERROR - 2015-01-27 14:29:08 --> Page Missing: images/blog/thumb1.jpg
ERROR - 2015-01-27 14:29:10 --> Page Missing: images/blog/thumb2.jpg
ERROR - 2015-01-27 14:29:12 --> Page Missing: images/blog/thumb3.jpg
ERROR - 2015-01-27 14:29:13 --> Page Missing: images/slider/bg1.jpg
ERROR - 2015-01-27 14:29:15 --> Page Missing: images/slider/bg2.jpg
ERROR - 2015-01-27 14:29:18 --> Page Missing: images/slider/bg3.jpg
ERROR - 2015-01-27 14:29:21 --> Page Missing: images/ico/favicon.ico
ERROR - 2015-01-27 14:31:14 --> Page Missing: js/jquery.prettyPhoto.js
ERROR - 2015-01-27 14:31:16 --> Page Missing: js/jquery.js
ERROR - 2015-01-27 14:31:18 --> Page Missing: js/main.js
ERROR - 2015-01-27 14:31:20 --> Page Missing: js/bootstrap.min.js
ERROR - 2015-01-27 14:31:22 --> Page Missing: images/logo.png
ERROR - 2015-01-27 14:31:24 --> Page Missing: images/portfolio/recent/item1.png
ERROR - 2015-01-27 14:31:26 --> Page Missing: images/portfolio/recent/item3.png
ERROR - 2015-01-27 14:31:27 --> Page Missing: images/portfolio/recent/item2.png
ERROR - 2015-01-27 14:31:30 --> Page Missing: images/blog/thumb1.jpg
ERROR - 2015-01-27 14:31:32 --> Page Missing: images/blog/thumb2.jpg
ERROR - 2015-01-27 14:31:35 --> Page Missing: js/jquery.prettyPhoto.js
ERROR - 2015-01-27 14:31:38 --> Page Missing: images/blog/thumb3.jpg
ERROR - 2015-01-27 14:31:40 --> Page Missing: images/slider/bg1.jpg
ERROR - 2015-01-27 14:31:42 --> Page Missing: images/slider/bg2.jpg
ERROR - 2015-01-27 14:31:44 --> Page Missing: images/slider/bg3.jpg
ERROR - 2015-01-27 14:31:47 --> Page Missing: js/main.js
ERROR - 2015-01-27 14:35:23 --> Page Missing: js/jquery.prettyPhoto.js
ERROR - 2015-01-27 14:35:29 --> Page Missing: js/main.js
ERROR - 2015-01-27 14:35:36 --> Page Missing: js/jquery.js
ERROR - 2015-01-27 14:35:41 --> Page Missing: addons/shared_addons/themes/flatimages/logo.png
ERROR - 2015-01-27 14:35:44 --> Page Missing: js/bootstrap.min.js
ERROR - 2015-01-27 14:35:48 --> Page Missing: js/jquery.prettyPhoto.js
ERROR - 2015-01-27 14:35:52 --> Page Missing: js/main.js
ERROR - 2015-01-27 14:37:13 --> Page Missing: addons/shared_addons/themes/flatimages/logo.png
ERROR - 2015-01-27 15:02:11 --> Page Missing: kok
ERROR - 2015-01-27 15:09:59 --> Page Missing: kok
ERROR - 2015-01-27 15:10:46 --> Page Missing: kok
ERROR - 2015-01-27 15:11:20 --> Page Missing: kok
ERROR - 2015-01-27 15:29:52 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-01-27 15:30:42 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-01-27 15:32:42 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-01-27 15:36:16 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-01-27 15:37:44 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-01-27 15:40:39 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-01-27 15:41:08 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-01-27 15:45:54 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 15:48:13 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-01-27 15:49:47 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 15:53:32 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 15:54:16 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 15:55:09 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 15:56:40 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 15:56:59 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 15:58:14 --> Severity: Notice  --> Array to string conversion D:\xampp\htdocs\seno_web\system\cms\libraries\Lex\Parser.php 190
ERROR - 2015-01-27 15:58:17 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 15:58:58 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 16:00:32 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 16:16:02 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 16:17:44 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 16:29:14 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 16:44:05 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 16:44:22 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-27 17:05:00 --> Severity: Notice  --> Array to string conversion D:\xampp\htdocs\seno_web\system\cms\libraries\Lex\Parser.php 190
ERROR - 2015-01-27 17:12:45 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
