<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-28 14:44:47 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-28 15:42:57 --> Page Missing: search/addons/shared_addons/themes/flat/images/blog/thumb2.jpg
ERROR - 2015-01-28 15:42:59 --> Page Missing: search/addons/shared_addons/themes/flat/images/logo.png
ERROR - 2015-01-28 15:43:02 --> Page Missing: search/addons/shared_addons/themes/flat/images/blog/thumb1.jpg
ERROR - 2015-01-28 15:43:05 --> Page Missing: search/addons/shared_addons/themes/flat/images/ico/favicon.ico
ERROR - 2015-01-28 15:43:07 --> Page Missing: search/addons/shared_addons/themes/flat/images/blog/thumb3.jpg
ERROR - 2015-01-28 15:43:08 --> Page Missing: search/addons/shared_addons/themes/flat/images/ico/favicon.ico
ERROR - 2015-01-28 15:45:57 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-28 15:46:04 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-28 15:49:19 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-01-28 16:50:20 --> Severity: Warning  --> ucfirst() expects exactly 1 parameter, 2 given D:\xampp\htdocs\seno_web\system\cms\modules\contact\plugin.php 519
ERROR - 2015-01-28 16:58:28 --> Page Missing: images/blog/blog1.jpg
