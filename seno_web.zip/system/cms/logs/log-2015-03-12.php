<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-12 03:16:59 --> Severity: Notice  --> unserialize(): Error at offset 372 of 624 bytes D:\xampp\htdocs\seno_web\system\cms\libraries\Pyrocache.php 297
ERROR - 2015-03-12 03:17:53 --> Page Missing: addons/shared_addons/themes/flat/images/logo.png
ERROR - 2015-03-12 03:28:15 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg1.jpg
ERROR - 2015-03-12 03:28:21 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg1.jpg
ERROR - 2015-03-12 03:29:37 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg1.jpg
ERROR - 2015-03-12 03:29:47 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg1.jpg
ERROR - 2015-03-12 03:29:49 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg1.jpg
ERROR - 2015-03-12 03:29:51 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg1.jpg
ERROR - 2015-03-12 03:30:31 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg1.jpg
ERROR - 2015-03-12 03:31:00 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg1.jpg
ERROR - 2015-03-12 03:31:03 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg1.jpg
ERROR - 2015-03-12 03:31:07 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg1.jpg
ERROR - 2015-03-12 03:33:05 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg1.jpg
ERROR - 2015-03-12 03:40:35 --> Page Missing: addons/shared_addons/themes/flat/images/slider/bg11.png
ERROR - 2015-03-12 05:23:36 --> Page Missing: addons/shared_addons/themes/flat/images/portfolio/recent/item3.png
ERROR - 2015-03-12 05:24:27 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-03-12 05:27:08 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-03-12 05:29:05 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-03-12 05:29:35 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-03-12 05:33:49 --> Page Missing: images/blog/blog1.jpg
ERROR - 2015-03-12 06:01:56 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-03-12 06:02:01 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-03-12 06:02:04 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-03-12 06:02:26 --> Severity: Runtime Notice  --> Only variables should be assigned by reference D:\xampp\htdocs\seno_web\system\cms\plugins\theme.php 414
ERROR - 2015-03-12 06:04:27 --> Page Missing: images/blog/thumb1.jpg
