<?php defined('BASEPATH') OR exit('No direct script access allowed');

// inline help html. Only 'help_body' is used.
$lang['help_body'] = "
<h4>Visão geral</h4>
<p>Administradores podem alterar o tema do site por completo em apenas alguns cliques.</p>

<h4>Alterando o tema do site</h4>
<p>É simples! Visualize o tema desejado e se você gostar basta selecioná-lo e clicar em Salvar.</p>";