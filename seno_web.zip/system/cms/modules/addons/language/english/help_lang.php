<?php defined('BASEPATH') OR exit('No direct script access allowed');

// inline help html. Only 'help_body' is used.
$lang['help_body'] = "
<h4>Overview</h4>
<p>Administrators can change the entire website theme with a few clicks.</p>

<h4>Changing the site theme</h4>
<p>It's simple! Preview the prospective theme and if you like it check its radio button and Save.</p>";