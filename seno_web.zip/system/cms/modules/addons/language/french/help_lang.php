<?php defined('BASEPATH') OR exit('No direct script access allowed');

// inline help html. Only 'help_body' is used.
$lang['help_body'] = "
<h4>Général</h4>
<p>Les administrateurs peuvent changer le thème général du site en quelques clics.</p>

<h4>Changer le Thème du site</h4>
<p>C'est très simple&nbsp;! Vous pouvez prévisualiser le thème que vous souhaiter, il suffit de sélectionner le bouton radio correspondant et cliquer sur le bouton Sauvegarder.</p>";