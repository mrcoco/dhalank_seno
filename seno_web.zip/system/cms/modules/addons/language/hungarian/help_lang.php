<?php defined('BASEPATH') OR exit('No direct script access allowed');

// inline help html. Only 'help_body' is used.
$lang['help_body'] = "
<h4>Leírás</h4>
<p>Az adminisztrátorok pár kattintással meg tudják változtatni az oldal témáját.</p>

<h4>Oldal témájának megváltoztatása</h4>
<p>Egyszerű! Nézd meg az előnézetet és ha tetszik, válaszd ki és mentsd.</p>";