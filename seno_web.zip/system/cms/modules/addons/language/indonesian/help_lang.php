<?php defined('BASEPATH') OR exit('No direct script access allowed');

// inline help html. Only 'help_body' is used.
$lang['help_body'] = "
<h4>Ikhtisar</h4>
<p>Administrator dapat mengubah keseluruhan tema tampilan situs hanya dengan beberapa klik.</p>

<h4>Mengubah tema situs</h4>
<p>Sangat sederhana! Lihat dahulu pratinjau dari tema yang ada, dan bila Anda suka pilih tombol radio button tema tersebut dan klik simpan.</p>";
