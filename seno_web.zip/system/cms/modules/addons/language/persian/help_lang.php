<?php defined('BASEPATH') OR exit('No direct script access allowed');

// inline help html. Only 'help_body' is used.
$lang['help_body'] = "
<h4>کلیات</h4>
<p>ادمین ها می توانند قالب سایت را با چند کلیک ساده تغییر دهند</p>

<h4>تغییر دادن قالب سایت</h4>
<p>بسیار ساده است، ابتدا قالب ها را ببینید و هر کدام را که خواستید به حالت  پیشفرض در بیاورید.</p>";