<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * PyroCMS
 * Русский перевод от Dark Preacher - dark[at]darklab.ru
 *
 * @package		PyroCMS
 * @author		Dark Preacher
 * @link			http://pyrocms.com
 */

// внутренняя помощь для модуля Темы
$lang['help_body'] = "
<h4>Введение</h4>
<p>
	Администраторы могут менять оформление всего сайта сделав всего пару кликов.
</p>
<hr />

<h4>Изменение темы оформления</h4>
<p>
	Это просто! Нажмите кнопку Предпросмотр справа от желаемой темы, если она вам понравилась - выберите её Темой по-умолчанию и нажмите Сохранить.
</p>
";